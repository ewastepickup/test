---
id: docs_install
guide: docs_getting_started
layout: pages/install
---
