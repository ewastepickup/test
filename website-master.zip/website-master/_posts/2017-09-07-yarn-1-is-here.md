---
layout     : post
title      : "Yarn 1.0 is Here"
author     : Burak Yigit Kaya
author_url : "https://twitter.com/madbyk"
date       : 2017-09-07 8:00:00
categories : announcements
share_text : "Yarn 1.0: Workspaces, auto-merging lockfiles, selective versions resolutions"
---

After a long wait, [Yarn 1.0 is out](https://code.facebook.com/posts/274518539716230)!
